let sor;
function huz(){
  sor = event.target;
}
function elenged(){
  let e = event;
  e.preventDefault();

  let children= Array.from(e.target.parentNode.parentNode.children);
  if(children.indexOf(e.target.parentNode)>children.indexOf(sor))
    e.target.parentNode.after(sor);
  else
    e.target.parentNode.before(sor);
}